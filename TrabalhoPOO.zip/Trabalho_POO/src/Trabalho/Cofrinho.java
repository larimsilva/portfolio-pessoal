package Trabalho;

import java.util.ArrayList;
import java.util.List;

class Cofrinho {
    private List<Moeda> moedas;

    public Cofrinho() {
        moedas = new ArrayList<>(); //lista de moedas vazia
    }

    public void adicionarMoeda(Moeda moeda) {
        moedas.add(moeda); // Adiciona uma moeda à lista de moedas
        System.out.println("Moeda adicionada com sucesso.");
    }

    public void removerMoeda(int indice) {
    	
        if (indice >= 0 && indice < moedas.size()) {
            moedas.remove(indice);// Remove a moeda com o índice escolido da lista
            System.out.println("Moeda removida com sucesso.");
        } else {
            System.out.println("Índice inválido.");
        }
    }

    public List<Moeda> listarMoedas() {
        return moedas; // Retorna a lista de moedas
    }

   
    public double converterParaReal() {
        double valorTotalReal = 0;
        for (Moeda moeda : moedas) {
            if (moeda instanceof Real) {
                valorTotalReal += moeda.valor; 
            } else if (moeda instanceof Dolar) {
                valorTotalReal += moeda.converter(4.77); //conversão do Dólar para Real
            } else if (moeda instanceof Euro) {
                valorTotalReal += moeda.converter(5.23); //conversão do Euro para Real
            }
        }
        return valorTotalReal;// Retorna o valor total em Real
    }
}

