package Trabalho;

public class Dolar extends Moeda {
    public Dolar(double valor) {
        super(valor);
    }

    @Override
    public String getNome() {
        return "Dolar";
    }

    public void info() {
        System.out.println("Moeda: Dolar");
        System.out.println("Valor: " + valor + " USD");
    }

    public double converter(double taxa) {
        return valor * taxa;// Converte o valor da moeda para Real
    }
}
