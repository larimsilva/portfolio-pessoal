package Trabalho;

public class Real extends Moeda {
    public Real(double valor) {
        super(valor);
    }

    @Override
    public String getNome() {
        return "Real";
    }

    public void info() {
  
        System.out.println("Moeda: Real");
        System.out.println("Valor: " + valor + " BRL");
    }

    public double converter(double taxa) {
        return valor * taxa;
    }
}
