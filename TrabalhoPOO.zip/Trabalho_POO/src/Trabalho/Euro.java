package Trabalho;

public class Euro extends Moeda {
    public Euro(double valor) {
        super(valor);
    }

    @Override
    public String getNome() {
        return "Euro";
    }

    public void info() {
        System.out.println("Moeda: Euro");
        System.out.println("Valor: " + valor + " EUR");
    }

    public double converter(double taxa) {
        return valor * taxa;// Converte o valor da moeda  para Real
    }
}

