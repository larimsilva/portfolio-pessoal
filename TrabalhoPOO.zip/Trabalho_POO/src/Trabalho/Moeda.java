package Trabalho;
abstract class Moeda {
    double valor;

    public Moeda(double valor) {
        this.valor = valor;
    }

    public abstract String getNome();

    public void info() {
        System.out.println("Moeda: " + getNome());
        System.out.println("Valor: " + valor);
    }

    public double converter(double taxa) {
        return valor * taxa; //Converte o valor da moeda para outra moeda
    }
}

