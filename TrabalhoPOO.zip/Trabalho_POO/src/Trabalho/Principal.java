package Trabalho;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        int opcaoUsuario;

        Cofrinho cofrinho = new Cofrinho();
        	//Menu de opções
        System.out.println("_________COFRINHO________");
        System.out.println("1-Adicionar uma nova moeda: ");
        System.out.println("2-Remover moeda");
        System.out.println("3-Listar moedas");
        System.out.println("4-Calcular valor total e converter para Real");
        System.out.println("5-Sair");

        opcaoUsuario = teclado.nextInt();

        while (opcaoUsuario != 5) {

            switch (opcaoUsuario) {

                case 1:
                    int tipoMoeda = 0;
                    while (tipoMoeda > 3 || tipoMoeda <= 0) {
                   // opções de tipos de moeda
                        System.out.println("1-Real");
                        System.out.println("2-Dólar");
                        System.out.println("3-Euro");
                        tipoMoeda = teclado.nextInt();
                    }

                    double valorMoeda;
                    switch (tipoMoeda) {
                        case 1:
                            System.out.println("Qual o valor: ");
                            valorMoeda = teclado.nextDouble();
                            cofrinho.adicionarMoeda(new Real(valorMoeda));
                            break;
                        case 2:
                            System.out.println("Qual o valor: ");
                            valorMoeda = teclado.nextDouble();
                            cofrinho.adicionarMoeda(new Dolar(valorMoeda));
                            break;
                        case 3:
                            System.out.println("Qual o valor: ");
                            valorMoeda = teclado.nextDouble();
                            cofrinho.adicionarMoeda(new Euro(valorMoeda));
                            break;
                    }
                    break;

                case 2:
                    System.out.println("Índice da moeda a ser removida: ");
                    int indiceMoeda = teclado.nextInt();
                    cofrinho.removerMoeda(indiceMoeda);
                    break;

                case 3:
                    System.out.println("Moedas no cofrinho:");
                    for (Moeda moeda : cofrinho.listarMoedas()) {
                        moeda.info();
                        System.out.println();
                    }
                    break;

                case 4:
                    double valorTotalReal = cofrinho.converterParaReal();
                    
                    System.out.println("Valor total em Real: " + valorTotalReal);
                    break;

                default:
                    System.out.println("Opção inválida, tente novamente.");
                    break;
            }

            System.out.println("_________COFRINHO________");
            System.out.println("1-Adicionar uma nova moeda: ");
            System.out.println("2-Remover moeda");
            System.out.println("3-Listar moedas");
            System.out.println("4-Calcular valor total e converter para Real");
            System.out.println("5-Sair");

            opcaoUsuario = teclado.nextInt();
        }
    
        System.out.println("Programa encerrado...");	
        }
    }


